## Exercice
### Consignes :

- Affichez les valeurs dans le tableau en fonction des éléments figurants dans la base de données (servez vous du fichier sql ci joint),
- Créez des liens vers les fichiers qui permetteront de modifier, ajouter, supprimer et afficher (complétez le fichier products.php).
- Créez les fichiers nécessaires pour les traitements correspondants,
- Affichez le tableau (fichier products.php) après les modifications.

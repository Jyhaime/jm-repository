<?php 
//session_start();

if (isset($_POST['submit']))
{
    $email = $_POST['email'];
    $pass = $_POST['pass'];
    $pass1 = sha1($pass);

    $db = new PDO('mysql:host=localhost;dbname=password;charset=utf8','root','');

    $sql = "SELECT * FROM signit WHERE email = '$email' AND pass = '$pass1'  ";
    $result = $db->prepare($sql);
    $result->execute();

    if($result->rowCount() > 0)
    {
      //  $data = $result->fetchAll();
       // var_dump($data);
       // if(password_verify($pass, $data[0]["pass"]))
        //{
            
           // $_SESSION['email']= $email;
           // $_SESSION['pass']= $pass;
            header('Location: connected.php');
        //}
    }
    else
    {
        //Enregistrement auto si email inconnus :
       /* $pass = sha1($pass);
        $sql= "INSERT INTO signit (email,pass) VALUES ('$email', '$pass')";
        $req= $db->prepare($sql);
        $req->execute();
        echo "Enregistrement effectué"; */

        header('Location: signIt.php');

       
    }
}

?>

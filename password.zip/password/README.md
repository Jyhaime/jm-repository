## Exercice

## Consignes : 
- Créer un fichier qui receptionnera la data envoyée par le fichier signIt.php
- Créer la requête de connection à la base de donnée
- Vérifier si l'utilisateur possède les droits nécessaires pour pouvoir se connecter
- Si l'utilisateur a les droits, rediriger l'utilisateur sur la page connected.php

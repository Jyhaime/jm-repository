<?php

require 'admin.php';

$db = connect();

if(isset($_POST['ref'])){
    $ref = trim(htmlspecialchars($_POST['ref'],ENT_QUOTES));
} else{
    $ref = null;
}

if(isset($_POST['nom'])){
    $nom = trim(htmlspecialchars($_POST['nom'],ENT_QUOTES));
} else{
    $nom = null;
}

if(isset($_POST['prix'])){
    $prix = trim(htmlspecialchars($_POST['prix'],ENT_QUOTES));
} else{
    $prix = null;
}




var_dump ($ref);
echo $nom.' <br>';
echo $prix.' <br>';


$actif = 1;

try{
// préparation requetes

$req = $db->prepare("INSERT INTO article(nomArticle,categorieArticle,stock,prixArticle,imageArticle,actif)
VALUES (:nomArticle, :categorieArticle, :stock, :prixArticle, :imageArticle, :actif )");

// changement des parametre et controle des champ

$req->bindParam(":ref", $ref, PDO::PARAM_STR);
$req->bindParam(":nom", $nom, PDO::PARAM_STR);


$req->bindParam(":prix", $prix, PDO::PARAM_STR);


// execution de la requette

$req->execute();
header('Location: comfirm.php');
} catch(Exception $e) {
    echo $e->getMessage();

}
?>
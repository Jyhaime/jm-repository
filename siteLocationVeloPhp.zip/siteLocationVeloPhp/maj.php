<html>
<body>
<?
// connexion à la base
mysql_connect("localhost","root","") or die ("Impossible de se connecter");
mysql_select_db("base") or die("Impossible de trouver la base");           

// recuperation des valeurs du formulaire
$nom = $_POST['nom'];
$prix= $_POST['prix'];

// insertion des valeurs dans la base
$query = "INSERT INTO produit (nom,prix) VALUES ('$nom','$prix')";
$result=mysql_query($query);
mysql_close();
?>
Mise a jour faite
</body>
</html>